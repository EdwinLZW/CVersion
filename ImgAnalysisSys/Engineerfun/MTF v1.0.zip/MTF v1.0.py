#!/usr/bin/python
# -*- coding: utf-8 -*-

__author__ = "Zhouwu Liu"
__copyright__ = "Copyright 2019, PRMeasure Inc."
__email__ = "zhouwu.liu@prmeasure.com"

import numpy as np
import cv2
import math
import matplotlib.pyplot as plt


def diff(x):
    y = np.zeros(len(x)-2)
    for i in range(1, len(x)-2):
        y[i] = -0.5*x[i-1] + 0.5*x[i+1]
    return y


def rescale(img):
    # 将图像的比例设置为0到255之间的整数
    imin = img.min()
    img = img - imin
    imax = img.max()
    img = ((img/imax)*255).astype('uint8')
    return img


def apply_kernel(img, kernel):
    n = kernel.shape[0] - 1
    x, y = img.shape
    mask = np.ones((x - n, y - n))
    for i in range(0, x - n):
        for j in range(0, y - n):
            r1 = i + n + 1
            r2 = j + n + 1
            mask[i, j] = np.multiply(kernel, img[i:r1, j:r2]).sum()
    mask = rescale(mask)
    return mask


def ring(im, n, edge='extend', asym=False):
    if im.ndim == 2:
        x, y = im.shape
        b = np.zeros((x + 2 * n, y + 2 * n))
        if asym == True:
            b = np.zeros((x + 2 * n + 1, y + 2 * n + 1))
        b[n:(x + n), n:(y + n)] = im

        if edge == 'extend':
            b[0:n, 0:n] = im[0, 0]
            b[(x + n):(x + 2 * n), (y + n):(y + 2 * n)] = im[x - 1, y - 1]
            b[(x + n):(x + 2 * n), 0:n] = im[x - 1, 0]
            b[0:n, (y + n):(y + 2 * n)] = im[0, y - 1]

            b[0:n, n:(y + n)] = im[0, :]
            b[n:(x + n), 0:n] = im[:, 0:1]
            b[(x + n):(x + 2 * n), n:(y + n)] = im[(x - 1), :]
            b[n:(x + n), (y + n):(y + 2 * n)] = im[:, (y - 1):y]
        return b

    else:
        x, y, z = im.shape
        b = np.zeros((x + 2 * n, y + 2 * n, z))
        if asym == True:
            b = np.zeros((x + 2 * n + 1, y + 2 * n + 1, z))
        b[n:(x + n), n:(y + n), :] = im
        if edge == 'extend':
            b[0:n, 0:n, :] = im[0, 0, :]
            b[(x + n):(x + 2 * n), (y + n):(y + 2 * n), :] = im[x - 1, y - 1, :]
            b[(x + n):(x + 2 * n), 0:n, :] = im[x - 1, 0, :]
            b[0:n, (y + n):(y + 2 * n), :] = im[0, y - 1, :]

            b[0:n, n:(y + n), :] = im[0, :, :]
            b[n:(x + n), 0:n, :] = im[:, 0:1, :]
            b[(x + n):(x + 2 * n), n:(y + n), :] = im[(x - 1), :, :]
            b[n:(x + n), (y + n):(y + 2 * n), :] = im[:, (y - 1):y, :]
        return b


def gauss_blur(img):
    img = ring(img, 2)
    k_gauss = 1.0 / 159 * np.array(
        [[2, 4, 5, 4, 2], [4, 9, 12, 9, 4], [5, 12, 15, 12, 5], [4, 9, 12, 9, 4], [2, 4, 5, 4, 2]])
    img_gauss = apply_kernel(img, k_gauss)
    return img_gauss


def projection(A, b):
    AA = A.T.dot(A)  # A乘以A转置
    w = np.linalg.inv(AA).dot(A.T).dot(b)
    return A.dot(w), w


if __name__ == '__main__':
    # TODO  获取图像信息
    rawfile = np.fromfile('MTF_SFR.raw', dtype=np.uint8)  # 以float32读图片
    imgData = rawfile.reshape(2748, 3664)
    # img = cv2.resize(imgData, (2748/4, 3664/8))
    # TODO 选取刃边
    y, x = imgData.shape
    roi = imgData[x/2-200:x/2, y/2-50:y/2+100]
    r_y, r_x = roi.shape
    # print roi.shape
    # TODO 对刃边作平滑滤波
    gauss_roi = gauss_blur(roi)
    # TODO 2 像素值分布处理
    for i in range(0, gauss_roi.shape[0]):
        for j in range(0, gauss_roi.shape[1]):
            if gauss_roi[i, j] < 13:
                gauss_roi[i, j] = 13
            elif gauss_roi[i, j] > 210:
                gauss_roi[i, j] = 210
    # TODO 对刃边作拟合求得斜率和截距

    # TODO ESF
    esf = np.zeros([150], np.uint64)
    for i in xrange(gauss_roi.shape[1]):
        esf[i] = np.sum(gauss_roi[:, i])/200.0
    # TODO LSF
    lsf = diff(esf)
    index_list = []
    for k, v in enumerate(lsf):
        if v > 0.0:
            index_list.append(k)
    y1 = np.array(lsf[min(index_list):max(index_list)])
    x = np.arange(0, len(y1), 1)
    m = []
    for i in xrange(3):  # 这里选的最高次为x^2的多项式
        a = x ** (i)
        m.append(a)
    A = np.array(m).T
    b = y1.reshape(y1.shape[0], 1)
    yw, w = projection(A, b)
    for i in range(len(y1)):
        y1[i] = yw[i]
    lsf[min(index_list):min(index_list)+len(y1)] = y1
    # TODO fft傅立叶变换
    mtf = abs(np.fft.rfft(lsf).real)/200.0
    print mtf
    # TODO 显示
    # plt.title('ESF'), plt.plot(esf)
    # plt.title('LSF'), plt.plot(lsf)
    plt.title('MTF'), plt.plot(mtf)
    plt.show()
    # cv2.imshow('ROI with noise', roi)
    # cv2.imshow('Filtered ROI', gauss_roi)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
